./network.sh down
./network.sh up createChannel -ca -c blockchain2023
./network.sh deployCC -ccn placemarket -ccv 1 -ccp ../chaincode/placemarket/typescript -cci initLedger -ccl typescript